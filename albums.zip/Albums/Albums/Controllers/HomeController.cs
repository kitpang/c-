﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Albums.Models;

namespace Albums.Controllers
{
    public class HomeController : Controller
    {
		List<Album> albums = new List<Album>();
        // GET: Home

		public ActionResult Index()
        {
			Album album1 = new Album("Title uno", "artist uno", "Vinyl", 9.99M);
			albums.Add(album1);
			Album album2 = new Album("Title dos", "artist dos", "Vinyl", 19.99M);
			albums.Add(album2);
			Album album3 = new Album("Title tres", "artist tres", "CD", 12.99M);
			albums.Add(album3);

			return View(albums);
        }
    }
}