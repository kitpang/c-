﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PartyInvitation.Models;

namespace PartyInvitation.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public ActionResult RsvpForm()
		{
			return View();
		}

		[HttpPost]
		public ActionResult RsvpForm(GuestResponse guestResponse)
		{
			//to do - email party organiser
			if(ModelState.IsValid)
			{
				return View("Thanks", guestResponse);
			}

			return View();
		}

	}
}