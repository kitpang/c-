﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PartyInvitation.Models
{
	public class GuestResponse
	{
		[Required(ErrorMessage = "Please enter your name")]
		public string name { get; set; }

		[Required(ErrorMessage = "Please enter your email")]
		[RegularExpression(".+\\@.+\\..+", ErrorMessage = "Please enter a valid email address")]
		public string email { get; set; }

		[Required(ErrorMessage = "Please enter your phone number")]
		public string phone { get; set; }

		[Required(ErrorMessage = "Please say whether you'll attend")]
		public bool?  WillAttend { get; set;}

	}
}